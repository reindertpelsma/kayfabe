APPRES side=guest app=UnifiedMemoryStreams verdict=FAIL rc=139 secs=12 quiet=0 note=CUDA error at UnifiedMemoryStreams.cu:221 code=13(CUBLAS_STATUS_EXECUTION_FAILED) "cublasDgemv(handle[tid + 1], CUBLAS_OP_N, t.size, t.size, &one, t.data, t.siz boot=ap_mapfix_contain_b1 guest_xid=0 kf3_lines=1285 kf3_refusals=39
APPRES side=guest app=vectorAdd verdict=PASS rc=0 secs=2 quiet=1 note=- boot=ap_mapfix_contain_b1 guest_xid=0 kf3_lines=1078 kf3_refusals=4
APPRES side=guest app=matrixMul verdict=PASS rc=0 secs=1 quiet=0 note=- boot=ap_mapfix_contain_b1 guest_xid=0 kf3_lines=1092 kf3_refusals=4
APPRES side=guest app=deviceQuery verdict=PASS rc=0 secs=1 quiet=0 note=- boot=ap_mapfix_contain_b1 guest_xid=0 kf3_lines=1106 kf3_refusals=4
APPRES side=guest app=simpleStreams verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_contain_b1 guest_xid=0 kf3_lines=1120 kf3_refusals=4
APPRES side=guest app=UnifiedMemoryStreams verdict=FAIL rc=139 secs=2 quiet=0 note=CUDA error at UnifiedMemoryStreams.cu:202 code=719(cudaErrorLaunchFailure) "cudaStreamSynchronize(stream[0])"  boot=ap_mapfix_contain_b1 guest_xid=0 kf3_lines=1246 kf3_refusals=27
APPRES side=guest app=asyncAPI verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_contain_b1 guest_xid=0 kf3_lines=1120 kf3_refusals=4
