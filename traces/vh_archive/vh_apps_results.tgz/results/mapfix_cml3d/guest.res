APPRES side=guest app=clpeak verdict=FAIL rc=0 secs=129 quiet=9 note=clpeak: 4 test groups skipped (clFinish (-36)) boot=ap_mapfix_cml3d_b1 guest_xid=0 kf3_lines=3000 kf3_refusals=5
