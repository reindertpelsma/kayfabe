APPRES side=guest app=clpeak verdict=FAIL rc=0 secs=81 quiet=0 note=clpeak: 4 test groups skipped (clFinish (-36)) boot=ap_mapfix_clpeak_nb_b1 guest_xid=0 kf3_lines=1158 kf3_refusals=4
APPRES side=guest app=vectorAdd verdict=PASS rc=0 secs=3 quiet=2 note=- boot=ap_mapfix_clpeak_nb_b1 guest_xid=0 kf3_lines=1079 kf3_refusals=4
