APPRES side=guest app=UnifiedMemoryStreams verdict=FAIL rc=134 secs=14 quiet=0 note=CUDA error at UnifiedMemoryStreams.cu:214 code=719(cudaErrorLaunchFailure) "cudaStreamAttachMemAsync(stream[tid + 1], t.data, 0, cudaMemAttachSingle)"  boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1246 kf3_refusals=4
APPRES side=guest app=vectorAdd verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1085 kf3_refusals=4
APPRES side=guest app=matrixMul verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1091 kf3_refusals=4
APPRES side=guest app=deviceQuery verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1106 kf3_refusals=4
APPRES side=guest app=simpleStreams verdict=PASS rc=0 secs=4 quiet=1 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1121 kf3_refusals=4
APPRES side=guest app=asyncAPI verdict=PASS rc=0 secs=2 quiet=1 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1120 kf3_refusals=4
APPRES side=guest app=bandwidthTest verdict=PASS rc=0 secs=3 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1107 kf3_refusals=4
APPRES side=guest app=simpleCUBLAS verdict=PASS rc=0 secs=4 quiet=1 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1177 kf3_refusals=4
APPRES side=guest app=simpleCUFFT verdict=PASS rc=0 secs=1 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1090 kf3_refusals=3
APPRES side=guest app=reduction verdict=PASS rc=0 secs=3 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=3000 kf3_refusals=0
APPRES side=guest app=scan verdict=PASS rc=0 secs=4 quiet=1 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1091 kf3_refusals=2
APPRES side=guest app=BlackScholes verdict=PASS rc=0 secs=2 quiet=0 note=warn:Max absolute error: 1.192093E-05 boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1090 kf3_refusals=2
APPRES side=guest app=concurrentKernels verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1118 kf3_refusals=2
APPRES side=guest app=simpleIPC verdict=PASS rc=0 secs=4 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1843 kf3_refusals=2
APPRES side=guest app=simpleCallback verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1104 kf3_refusals=2
APPRES side=guest app=stream_triad verdict=PASS rc=0 secs=3 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1075 kf3_refusals=2
APPRES side=guest app=sgemm_cublas verdict=PASS rc=0 secs=3 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1160 kf3_refusals=2
APPRES side=guest app=vectorAddDrv verdict=PASS rc=0 secs=2 quiet=1 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1069 kf3_refusals=2
APPRES side=guest app=matrixMulDrv verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1070 kf3_refusals=2
APPRES side=guest app=simpleAtomicIntrinsics verdict=PASS rc=0 secs=2 quiet=1 note=- boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1089 kf3_refusals=2
APPRES side=guest app=UnifiedMemoryStreams verdict=FAIL rc=134 secs=2 quiet=0 note=CUDA error at UnifiedMemoryStreams.cu:221 code=13(CUBLAS_STATUS_EXECUTION_FAILED) "cublasDgemv(handle[tid + 1], CUBLAS_OP_N, t.size, t.size, &one, t.data, t.siz boot=ap_mapfix_g1_b1 guest_xid=0 kf3_lines=1221 kf3_refusals=2
