APPRES side=guest app=clpeak verdict=PASS rc=0 secs=159 quiet=0 note=- boot=ap_mapfix_cfix1_b1 guest_xid=0 kf3_lines=3000 kf3_refusals=5
APPRES side=guest app=vectorAdd verdict=PASS rc=0 secs=3 quiet=1 note=- boot=ap_mapfix_cfix1_b1 guest_xid=0 kf3_lines=3000 kf3_refusals=5
