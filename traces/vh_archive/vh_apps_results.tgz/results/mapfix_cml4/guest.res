APPRES side=guest app=clpeak verdict=FAIL rc=0 secs=82 quiet=1 note=clpeak: 4 test groups skipped (clFinish (-36)) boot=ap_mapfix_cml4_b1 guest_xid=0 kf3_lines=3000 kf3_refusals=5
