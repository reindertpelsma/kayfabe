APPRES side=guest app=clpeak verdict=FAIL rc=0 secs=169 quiet=0 note=clpeak: 4 test groups skipped (clFinish (-36)) boot=ap_mapfix_clpeak_b1 guest_xid=0 kf3_lines=1210 kf3_refusals=4
APPRES side=guest app=vectorAdd verdict=PASS rc=0 secs=2 quiet=0 note=- boot=ap_mapfix_clpeak_b1 guest_xid=0 kf3_lines=1080 kf3_refusals=4
